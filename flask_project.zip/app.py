
from flask import Flask, request, send_file, render_template
from PIL import Image
import pytesseract
import io
import re

app = Flask(__name__)

def convert_to_hwp_format(text):
    text = text.replace(r'\frac', 'FRAC')
    text = text.replace(r'\int', 'INT')
    text = re.sub(r'\\Delta', 'DELTA', text)
    return text

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        file = request.files["file"]
        if file:
            image = Image.open(file.stream)
            raw_text = pytesseract.image_to_string(image, lang='eng+kor')
            formatted_text = convert_to_hwp_format(raw_text)
            
            return send_file(
                io.BytesIO(formatted_text.encode('utf-8')),
                mimetype="text/plain",
                as_attachment=True,
                download_name="converted_equations.txt"
            )
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
